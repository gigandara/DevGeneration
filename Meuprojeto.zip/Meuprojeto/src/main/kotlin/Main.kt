fun main() {
    println("Giovanna - Oi, amiga! Como vai?")
    println("Paula - OLha, dá pra melhorar. ")
    println("Giovanna - O que aconteceu?")
    println("Paula - Não recebi a promoção que eu queria. Disseram que eu cometo muitos erros.")
    println("Giovanna - Nossa, complicado. Mas acho que posso te ajudar.")
    println("Paula - Me conta então.")
    println("Giovanna - Seria ideal você observar esses erros. Eu sei que é chato mas tem que correr atrás.")
    println("Paula - Eu faço isso mas parece que todo o meu esforço é em vão.")
    println("Giovanna - Me manda mensagem no whatsapp que eu te passo mais dicas. Tenho que ir. Tchau!")
    println("Paula - Mando sim. Muito obrigada!")

    /* Conversa informal entre duas colegas

     */
    


}